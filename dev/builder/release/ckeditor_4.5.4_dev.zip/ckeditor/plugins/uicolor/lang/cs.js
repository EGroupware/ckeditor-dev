﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","cs",{title:"Výběr barvy rozhraní",preview:"Živý náhled",config:"Vložte tento řetězec do vašeho souboru config.js",predefined:"Přednastavené sady barev"});