﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","it",{abort:"Caricamento interrotto dall'utente.",doneOne:"Il file è stato caricato correttamente.",doneMany:"%1 file sono stati caricati correttamente.",uploadOne:"Caricamento del file ({percentage}%)...",uploadMany:"Caricamento dei file, {current} di {max} completati ({percentage}%)..."});