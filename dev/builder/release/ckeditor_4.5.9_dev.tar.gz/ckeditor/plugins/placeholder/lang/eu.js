﻿/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","eu",{title:"Leku-marka propietateak",toolbar:"Leku-marka",name:"Leku-markaren izena",invalidName:"Leku-markak ezin du hutsik egon eta ezin ditu karaktere hauek eduki: [, ], \x3c, \x3e",pathName:"leku-marka"});