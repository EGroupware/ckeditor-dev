﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","cs",{title:"Vlastnosti vyhrazeného prostoru",toolbar:"Vytvořit vyhrazený prostor",name:"Název vyhrazeného prostoru",invalidName:"Vyhrazený prostor nesmí být prázdný či obsahovat následující znaky: [, ], \x3c, \x3e",pathName:"Vyhrazený prostor"});