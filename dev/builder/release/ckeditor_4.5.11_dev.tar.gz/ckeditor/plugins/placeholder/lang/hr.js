﻿/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","hr",{title:"Svojstva rezerviranog mjesta",toolbar:"Napravi rezervirano mjesto",name:"Ime rezerviranog mjesta",invalidName:"Rezervirano mjesto ne može biti prazno niti može sadržavati ijedan od sljedećih znakova: [, ], \x3c, \x3e",pathName:"rezervirano mjesto"});