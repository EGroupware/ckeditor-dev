﻿/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","gl",{abort:"Envío interrompido polo usuario.",doneOne:"Ficheiro enviado satisfactoriamente.",doneMany:"%1 ficheiros enviados satisfactoriamente.",uploadOne:"Enviando o ficheiro ({percentage}%)...",uploadMany:"Enviando ficheiros, {current} de {max} feito o ({percentage}%)..."});