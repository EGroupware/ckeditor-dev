﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","ku",{title:"هەڵگری ڕەنگ بۆ ڕووکاری بەکارهێنەر",preview:"پێشبینین بە زیندوویی",config:"ئەم دەقانە بلکێنە بە پەڕگەی config.js-fil",predefined:"کۆمەڵە ڕەنگە دیاریکراوەکانی پێشوو"});